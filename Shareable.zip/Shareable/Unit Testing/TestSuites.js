function Add(x,y){
    return x + y;
}
describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});

describe("An addition suite", function() {
  it("add two numbers", function() {
    expect(Add(2,3)).toBe(50);
  });
});

