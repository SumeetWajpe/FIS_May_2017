import {Component,Input} from '@angular/core';

@Component({
    selector:'product',    
    template:`
    <div class="Product">
    <h2> {{prodDetails.name | uppercase }} </h2>
                    <b> Price :  </b> {{prodDetails.price | currency:'INR':true }} <br/>
                    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/>
                    <b> Date : </b> {{prodDetails.launchdate | date:'medium'}}  <br/> 
     <!-- Raw Details :   {{ prodDetails | json }}      -->
     <b> Description: </b> {{prodDetails.description | summary:30 }}
        </div>        
                    `,
                    styleUrls:['./app/product.css']
                    // styles:[`                    
                    // .Product{
                    //     background-color:yellow;
                    //     border:2px solid red;
                    //     border-radius:10px;
                    //     margin:20px;
                    //     padding:20px;
                    // }            
                    // `]
                    
})
export class ProductComponent{

 @Input('pDetails')   prodDetails:any={};

}