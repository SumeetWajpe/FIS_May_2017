import {Component} from '@angular/core';

@Component({
    selector:'shoppingcart',
    templateUrl:'/app/shoppingcart.component.html'
//     template:`<h1> Shopping Cart </h1>

//    <!--  <div *ngIf="products.length == 0">
//             <h1> You dont have any products yet ! </h1>
//     </div>
//     <div *ngIf="products.length !=0">
//         <div *ngFor="let p of products">
//            <product [pDetails]="p"></product>
//        </div>   
//     </div> -->

// <!--
//     Search Product Here : <input type="text" [(ngModel)]="name" />
//     <div [ngSwitch]="name">
//     <p *ngSwitchCase="'Laptop'">Laptop</p>
//     <p *ngSwitchCase="'Desktop'">Desktop</p>
//     <p *ngSwitchCase="'Palmtop'">Palmtop</p>
//     <p *ngSwitchCase="'Tabletop'">Tabletop</p>
//     <p *ngSwitchDefault>No products available !</p>
//     </div>  -->


// <!--
//  Search Product Here : <input type="text" [(ngModel)]="productToBeSearched" />
  
//   <div [ngSwitch]="productToBeSearched">
//     <div *ngFor="let p of products">
//         <div *ngSwitchCase="p.name">
//            <product [pDetails]="p"></product>
//         </div>
//        </div> 
//        <div *ngIf="productToBeSearched.length > 0">
//        <h2 *ngSwitchDefault> This product does not exist !</h2>
//        </div>  
//  </div>
// -->         
//     `
})
export class ShoppingCartComponent{
    productToBeSearched:string="";
    newProduct:any={};

    products:any[] = [
        {name:'Laptop',price:50000,quantity:100,rating:4,launchdate:new Date(),
        description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"},
        {name:'LED TV',price:25000,quantity:10,rating:3.2780,launchdate:new Date(),description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"},
        {name:'Desktop',price:10000,quantity:200,rating:3,launchdate:new Date(),description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"},
        {name:'Mobile',price:20000,quantity:1000,rating:5,launchdate:new Date(),description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"},
        {name:'Camera',price:90000,quantity:10,rating:4,launchdate:new Date(),description:"Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"}        
        ];


        onFormSubmit(formPassed:any,e:any){
                console.log(formPassed.valid);
                e.preventDefault(); // suppress submitting of the form !

                let newProductToBeAdded = {
                    name:this.newProduct.name,
                    price:this.newProduct.price,
                    quantity:this.newProduct.quantity,
                    rating:this.newProduct.rating,
                    
                }
                this.products.push(newProductToBeAdded);
        }

}