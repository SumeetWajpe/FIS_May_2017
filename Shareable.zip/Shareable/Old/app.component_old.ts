import { Component } from '@angular/core';


@Component({
  selector: 'my-app',
  template:`<shoppingcart></shoppingcart>
  
  `
//templateUrl:'/app/app.component.html'
// template:`

//   <input type="text" [value]="name" (input)="onChangeHandler($event)" />
// {{name}}

// <input type="text" [(ngModel)]="name" />

// `
})
export class AppComponent  { 
  name:string = 'Angular JS 2.0';
  imageUrl:string = "https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg";
  isSuccess:boolean = true;
  isButton:boolean = true;
  isSmall:boolean = true;

  onChangeHandler(e:any){
      let txtValue = e.target.value;
      this.name = txtValue;
  }
  
 }
