import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  // template: `<course></course>
  // <course></course>`,
   //template: `<posts></posts>`,

   template:`
              <nav>
                <a routerLink="/courses" routerLinkActive="active" class="btn btn-primary">Courses </a>
                <a routerLink="/posts" routerLinkActive="active" class="btn btn-primary">Posts </a>
                <router-outlet></router-outlet>
              </nav>
   `
})
export class AppComponent  { name = 'Angular'; }
