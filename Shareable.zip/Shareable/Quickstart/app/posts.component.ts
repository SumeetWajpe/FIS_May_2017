import {Component} from '@angular/core';
import {PostsService} from './posts.service';

@Component({
    selector:'posts',
    template:`
          <h2>Posts</h2>
          <div>
            <ul>
                <li *ngFor="let p of responseData">
                <a [routerLink]="['/posts',p.id]" routerLinkActive="active">
                {{p.title}}
                </a>
                </li>
            </ul>
          </div>
    `
    ,providers:[PostsService]
})
export class PostsComponent{
responseData:any;
constructor(private _posts:PostsService){
    this._posts.getAllPosts()
    .then((response) => {
            this.responseData = response;
        })
    .catch(err => console.log(err));
}

}