import {Component} from '@angular/core';
import {PostsService} from './posts.service';
import {ActivatedRoute} from '@angular/router';

@Component({
    selector:'post-details',
    template:`
        <div style="border:2px solid black;border-radius:20px;padding:20px;margin:20px;">
            <h1> Post Details </h1>
           <h2> {{ currentPost.title }} </h2>
           <h3> User Id : </h3> {{ currentPost.userId }}
           <h3> Id : </h3> {{ currentPost.id }}
           
        </div>       
    `
    ,providers:[PostsService]
})
export class PostDetailsComponent{
    postId:number;
    currentPost:any={};
constructor(private srv:PostsService,private currRoute:ActivatedRoute){
    
}

ngOnInit(){
    this.srv.getAllPosts().then((response:any) => {
        this.currRoute.params.subscribe((parameters:any) => {
            this.postId = parameters["id"];
            response.forEach((post:any) => {
                        if(post.id == this.postId){
                            this.currentPost = post;
                        }
            });
        });
    });
}


}