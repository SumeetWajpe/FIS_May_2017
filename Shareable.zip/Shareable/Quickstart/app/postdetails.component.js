"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var posts_service_1 = require('./posts.service');
var router_1 = require('@angular/router');
var PostDetailsComponent = (function () {
    function PostDetailsComponent(srv, currRoute) {
        this.srv = srv;
        this.currRoute = currRoute;
        this.currentPost = {};
    }
    PostDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.srv.getAllPosts().then(function (response) {
            _this.currRoute.params.subscribe(function (parameters) {
                _this.postId = parameters["id"];
                response.forEach(function (post) {
                    if (post.id == _this.postId) {
                        _this.currentPost = post;
                    }
                });
            });
        });
    };
    PostDetailsComponent = __decorate([
        core_1.Component({
            selector: 'post-details',
            template: "\n        <div style=\"border:2px solid black;border-radius:20px;padding:20px;margin:20px;\">\n            <h1> Post Details </h1>\n           <h2> {{ currentPost.title }} </h2>\n           <h3> User Id : </h3> {{ currentPost.userId }}\n           <h3> Id : </h3> {{ currentPost.id }}\n           \n        </div>       \n    ",
            providers: [posts_service_1.PostsService]
        }), 
        __metadata('design:paramtypes', [posts_service_1.PostsService, router_1.ActivatedRoute])
    ], PostDetailsComponent);
    return PostDetailsComponent;
}());
exports.PostDetailsComponent = PostDetailsComponent;
//# sourceMappingURL=postdetails.component.js.map