import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
    constructor(private http:Http){
        
    }

    getAllPosts(){
        // return all posts here
    //  return  this.http.get('https://jsonplaceholder.typicode.com/posts')
    //     .map(res => res.json()); // returns an Observable collection []
    
    return  this.http.get('https://jsonplaceholder.typicode.com/posts')
        .map(res => res.json()).toPromise(); // returns an Observable collection []
  
}

}