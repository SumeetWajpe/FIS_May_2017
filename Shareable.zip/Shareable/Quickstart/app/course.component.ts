import {Component} from '@angular/core';
import {CourseService} from './course.service';


@Component({
    selector:'course',
    template:`
        <div style="border:2px solid black;border-radius:20px;padding:20px;margin:20px;">
            Enter Coursename : <input type="text" [(ngModel)]="courseToBAdded" /> {{courseReceived}} <br/>
             <input type="button" class="btn btn-success"  value="Add>>" (click)="AddNewCourse()" />
             <input type="button" class="btn btn-primary" value="Get Random Course" (click)="GetCourse()" />
        </div>       
    `
    //,providers:[CourseService]
})
export class CourseComponent{
courseToBAdded:string = "";
courseReceived:string = "";

constructor(private srv:CourseService){
    
}

AddNewCourse(){
    this.srv.insertNewCourse(this.courseToBAdded)
}

GetCourse(){
    this.courseReceived = this.srv.getRandomCourse();
 }

}