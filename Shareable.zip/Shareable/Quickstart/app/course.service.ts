

export class CourseService{

listOfCourses:string[] = ["AngularJS","ReactJS","NodeJS"];

getRandomCourse():string{
    return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)];

}

getAllCourses():string[]{
    return this.listOfCourses;
}

insertNewCourse(newCourse:string):void{
    console.log(newCourse + " Added !");
    this.listOfCourses.push(newCourse);
}


}