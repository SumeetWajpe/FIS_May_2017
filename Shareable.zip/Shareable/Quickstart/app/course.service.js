"use strict";
var CourseService = (function () {
    function CourseService() {
        this.listOfCourses = ["AngularJS", "ReactJS", "NodeJS"];
    }
    CourseService.prototype.getRandomCourse = function () {
        return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)];
    };
    CourseService.prototype.getAllCourses = function () {
        return this.listOfCourses;
    };
    CourseService.prototype.insertNewCourse = function (newCourse) {
        console.log(newCourse + " Added !");
        this.listOfCourses.push(newCourse);
    };
    return CourseService;
}());
exports.CourseService = CourseService;
//# sourceMappingURL=course.service.js.map